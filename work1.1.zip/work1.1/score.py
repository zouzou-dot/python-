"""
成绩管理模块
"""

from utils import Utils


class ScoreManager:
    """成绩管理类"""

    def __init__(self):
        """初始化成绩管理器"""
        # 成绩使用嵌套字典存储
        # 数据结构: {学号: {课程名: 成绩}}
        self.scores = {}

    def set_score(self, stu_id, course, score):
        """
        设置学生某课程成绩
        输入: 学号, 课程名, 成绩
        处理: 存储成绩到数据结构中
        输出: 布尔值表示是否成功
        """
        if not Utils.validate_score(score):
            return False

        if stu_id not in self.scores:
            self.scores[stu_id] = {}

        self.scores[stu_id][course] = score
        return True

    def get_score(self, stu_id, course):
        """
        获取学生某课程成绩
        输入: 学号, 课程名
        处理: 查询成绩
        输出: 成绩或None
        """
        if stu_id in self.scores:
            return self.scores[stu_id].get(course)
        return None

    def get_student_scores(self, stu_id):
        """
        获取学生的全部成绩
        输入: 学号
        处理: 返回该生所有课程成绩
        输出: 成绩字典
        """
        return self.scores.get(stu_id, {})

    def get_course_all_scores(self, course):
        """
        获取某课程所有学生的成绩
        输入: 课程名
        处理: 遍历所有学生，收集该课程成绩
        输出: 字典 {学号: 成绩}
        """
        result = {}
        for stu_id, course_scores in self.scores.items():
            if course in course_scores:
                result[stu_id] = course_scores[course]
        return result

    def modify_score(self, stu_id, course, new_score):
        """
        修改学生某课程成绩
        输入: 学号, 课程名, 新成绩
        处理: 检查是否存在原成绩，若存在则修改
        输出: 布尔值表示是否成功
        """
        if not Utils.validate_score(new_score):
            return False

        if stu_id not in self.scores:
            return False

        if course not in self.scores[stu_id]:
            return False

        self.scores[stu_id][course] = new_score
        return True

    def delete_student_scores(self, stu_id):
        """
        删除某学生的所有成绩（用于删除学生时）
        输入: 学号
        处理: 删除该生所有成绩记录
        输出: 布尔值
        """
        if stu_id in self.scores:
            del self.scores[stu_id]
            return True
        return False

    def get_student_average(self, stu_id):
        """
        计算学生平均分
        输入: 学号
        处理: 遍历该生所有成绩计算平均
        输出: 平均分，若无成绩返回0
        """
        student_scores = self.get_student_scores(stu_id)
        if not student_scores:
            return 0

        total = sum(student_scores.values())
        count = len(student_scores)
        return total / count if count > 0 else 0

    def get_student_total(self, stu_id):
        """
        计算学生总分
        输入: 学号
        处理: 遍历该生所有成绩计算总分
        输出: 总分
        """
        student_scores = self.get_student_scores(stu_id)
        return sum(student_scores.values())

    def get_all_students_with_scores(self):
        """
        获取所有有成绩记录的学生学号
        输出: 学号列表
        """
        return list(self.scores.keys())