"""
工具函数模块
"""


class Utils:
    """工具类，包含常用验证和辅助函数"""

    # 课程列表
    COURSES = ['大数据与人工智能', '数学分析', '高等代数', '英语']

    @staticmethod
    def validate_score(score):
        """
        验证成绩是否合法
        输入: 成绩值
        处理: 检查是否为数字且在0-100之间
        输出: 布尔值
        """
        try:
            score_num = float(score)
            return 0 <= score_num <= 100
        except (ValueError, TypeError):
            return False

    @staticmethod
    def get_nonempty_input(prompt):
        """
        获取非空输入
        输入: 提示信息
        处理: 循环提示直到输入非空字符串
        输出: 输入的字符串
        """
        while True:
            value = input(prompt).strip()
            if value:
                return value
            print("输入不能为空，请重新输入")

    @staticmethod
    def get_gender_input(prompt):
        """
        获取性别输入
        输入: 提示信息
        处理: 验证性别格式
        输出: 性别字符串
        """
        while True:
            gender = input(prompt).strip()
            if gender in ['男', '女']:
                return gender
            print("性别只能输入'男'或'女'，请重新输入")

    @staticmethod
    def is_valid_stu_id(stu_id):
        """
        验证学号格式（简单验证）
        输入: 学号
        输出: 布尔值
        """
        if not stu_id:
            return False
        # 学号可以是数字或字符串，这里只检查非空
        return len(stu_id.strip()) > 0