"""
成绩统计分析模块
"""

from utils import Utils


class StatisticsManager:
    """成绩统计分析类"""

    def __init__(self, student_manager, score_manager):
        """
        初始化统计管理器
        输入: 学生管理器对象, 成绩管理器对象
        """
        self.student_manager = student_manager
        self.score_manager = score_manager
        self.student_rankings = []  # 存储学生排名数据
        self.course_stats = {}  # 存储课程统计数据
        self.score_distribution = {}  # 存储分数段分布

    def refresh(self):
        """刷新所有统计数据"""
        self._calculate_student_rankings()
        self._calculate_course_statistics()
        self._calculate_score_distribution()

    def _calculate_student_rankings(self):
        """
        计算学生总分和平均分排名
        处理: 遍历所有学生，计算总分平均分，按平均分排序
        输出: 存储到self.student_rankings
        """
        rankings = []
        all_students = self.student_manager.get_all_students()

        for student in all_students:
            stu_id = student['id']
            total = self.score_manager.get_student_total(stu_id)
            avg = self.score_manager.get_student_average(stu_id)

            # 只统计有成绩记录的学生
            if total > 0:
                rankings.append({
                    'id': stu_id,
                    'name': student['name'],
                    'class': student['class'],
                    'total': total,
                    'average': avg
                })

        # 按平均分从高到低排序
        self.student_rankings = sorted(rankings, key=lambda x: x['average'], reverse=True)

    def _calculate_course_statistics(self):
        """
        计算各课程的统计信息
        处理: 遍历所有课程，收集成绩，计算最高分、最低分、平均分、及格率、优秀率
        输出: 存储到self.course_stats
        """
        self.course_stats = {}

        for course in Utils.COURSES:
            scores = self.score_manager.get_course_all_scores(course)

            if not scores:
                self.course_stats[course] = {
                    'max': None, 'min': None, 'average': None,
                    'pass_rate': None, 'excellent_rate': None,
                    'student_count': 0
                }
                continue

            score_values = list(scores.values())
            max_score = max(score_values)
            min_score = min(score_values)
            average = sum(score_values) / len(score_values)

            # 计算及格率（>=60）
            pass_count = sum(1 for s in score_values if s >= 60)
            pass_rate = pass_count / len(score_values) * 100

            # 计算优秀率（>=90）
            excellent_count = sum(1 for s in score_values if s >= 90)
            excellent_rate = excellent_count / len(score_values) * 100

            self.course_stats[course] = {
                'max': max_score,
                'min': min_score,
                'average': average,
                'pass_rate': pass_rate,
                'excellent_rate': excellent_rate,
                'student_count': len(score_values)
            }

    def _calculate_score_distribution(self):
        """
        计算各课程的分数段分布
        处理: 遍历所有课程，按分数段统计人数
        输出: 存储到self.score_distribution
        """
        self.score_distribution = {}

        for course in Utils.COURSES:
            scores = self.score_manager.get_course_all_scores(course)

            distribution = {
                '优秀(90-100)': 0,
                '良好(80-89)': 0,
                '中等(70-79)': 0,
                '及格(60-69)': 0,
                '不及格(0-59)': 0
            }

            for score in scores.values():
                if score >= 90:
                    distribution['优秀(90-100)'] += 1
                elif score >= 80:
                    distribution['良好(80-89)'] += 1
                elif score >= 70:
                    distribution['中等(70-79)'] += 1
                elif score >= 60:
                    distribution['及格(60-69)'] += 1
                else:
                    distribution['不及格(0-59)'] += 1

            self.score_distribution[course] = distribution

    def print_student_rankings(self):
        """打印学生排名"""
        if not self.student_rankings:
            print("暂无学生成绩数据")
            return

        print("\n" + "=" * 70)
        print("学生成绩排名（按平均分）")
        print("=" * 70)
        print(f"{'排名':<4}{'学号':<12}{'姓名':<8}{'班级':<12}{'总分':<8}{'平均分':<8}")
        print("-" * 70)

        for i, student in enumerate(self.student_rankings, 1):
            print(f"{i:<4}{student['id']:<12}{student['name']:<8}"
                  f"{student['class']:<12}{student['total']:<8.1f}{student['average']:<8.2f}")

    def print_course_statistics(self):
        """打印课程统计信息"""
        print("\n" + "=" * 70)
        print("各课程统计信息")
        print("=" * 70)

        for course, stats in self.course_stats.items():
            if stats['max'] is None:
                print(f"\n【{course}】暂无成绩数据")
                continue

            print(f"\n【{course}】")
            print(f"  参考人数: {stats['student_count']}")
            print(f"  最高分: {stats['max']:.1f}")
            print(f"  最低分: {stats['min']:.1f}")
            print(f"  平均分: {stats['average']:.2f}")
            print(f"  及格率: {stats['pass_rate']:.1f}%")
            print(f"  优秀率: {stats['excellent_rate']:.1f}%")

    def print_score_distribution(self):
        """打印分数段分布"""
        print("\n" + "=" * 70)
        print("各课程分数段分布")
        print("=" * 70)

        for course, distribution in self.score_distribution.items():
            # 检查是否有数据
            has_data = any(v > 0 for v in distribution.values())
            if not has_data:
                print(f"\n【{course}】暂无成绩数据")
                continue

            print(f"\n【{course}】")
            total = sum(distribution.values())
            for level, count in distribution.items():
                percentage = count / total * 100 if total > 0 else 0
                bar = "█" * int(percentage / 2)  # 简单柱状图
                print(f"  {level:<14}: {count:>3}人 ({percentage:>5.1f}%) {bar}")

    def print_class_statistics(self):
        """打印按班级统计信息"""
        classes = self.student_manager.get_all_classes()
        if not classes:
            print("暂无班级数据")
            return

        print("\n" + "=" * 70)
        print("按班级成绩统计")
        print("=" * 70)

        for class_name in classes:
            print(f"\n【{class_name}】")

            # 获取该班级学生
            class_students = self.student_manager.get_students_by_class(class_name)
            stu_ids = [s['id'] for s in class_students]

            # 统计各科平均分
            print(f"{'课程':<12}{'参考人数':<8}{'平均分':<10}{'及格率':<10}{'优秀率':<10}")
            print("-" * 50)

            for course in Utils.COURSES:
                scores = []
                for stu_id in stu_ids:
                    score = self.score_manager.get_score(stu_id, course)
                    if score is not None:
                        scores.append(score)

                if scores:
                    avg = sum(scores) / len(scores)
                    pass_rate = sum(1 for s in scores if s >= 60) / len(scores) * 100
                    excellent_rate = sum(1 for s in scores if s >= 90) / len(scores) * 100
                    print(f"{course:<12}{len(scores):<8}{avg:<10.2f}{pass_rate:<10.1f}%{excellent_rate:<10.1f}%")
                else:
                    print(f"{course:<12}{0:<8}{'无数据':<10}{'无数据':<10}{'无数据':<10}")

    def get_student_rankings(self):
        """获取学生排名数据（用于导出）"""
        return self.student_rankings

    def get_course_stats(self):
        """获取课程统计数据（用于导出）"""
        return self.course_stats

    def get_score_distribution(self):
        """获取分数段分布数据（用于导出）"""
        return self.score_distribution

    def get_class_stats(self):
        """获取班级统计数据（用于导出）"""
        classes = self.student_manager.get_all_classes()
        class_stats = {}

        for class_name in classes:
            class_students = self.student_manager.get_students_by_class(class_name)
            stu_ids = [s['id'] for s in class_students]

            course_stats = {}
            for course in Utils.COURSES:
                scores = []
                for stu_id in stu_ids:
                    score = self.score_manager.get_score(stu_id, course)
                    if score is not None:
                        scores.append(score)

                if scores:
                    course_stats[course] = {
                        'avg': sum(scores) / len(scores),
                        'count': len(scores),
                        'pass_rate': sum(1 for s in scores if s >= 60) / len(scores) * 100,
                        'excellent_rate': sum(1 for s in scores if s >= 90) / len(scores) * 100
                    }
                else:
                    course_stats[course] = None

            class_stats[class_name] = course_stats

        return class_stats