"""
文件读写管理模块
"""

import json
import os
from datetime import datetime


class FileManager:
    """文件管理类"""

    def __init__(self):
        """初始化文件管理器"""
        self.student_file = "students.json"
        self.score_file = "scores.json"

    def load_students(self):
        """
        加载学生信息
        处理: 从JSON文件读取学生数据
        输出: 学生字典，若文件不存在或读取失败返回空字典
        """
        try:
            if not os.path.exists(self.student_file):
                return {}

            with open(self.student_file, 'r', encoding='utf-8') as f:
                students = json.load(f)
                return students
        except json.JSONDecodeError:
            print("学生数据文件格式错误，将使用空数据")
            return {}
        except Exception as e:
            print(f"读取学生数据文件时发生错误: {e}")
            return {}

    def save_students(self, students):
        """
        保存学生信息
        输入: 学生字典
        处理: 将学生数据写入JSON文件
        """
        try:
            with open(self.student_file, 'w', encoding='utf-8') as f:
                json.dump(students, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存学生数据失败: {e}")
            return False

    def load_scores(self):
        """
        加载成绩信息
        处理: 从JSON文件读取成绩数据
        输出: 成绩字典，若文件不存在或读取失败返回空字典
        """
        try:
            if not os.path.exists(self.score_file):
                return {}

            with open(self.score_file, 'r', encoding='utf-8') as f:
                scores = json.load(f)
                # 将键转换为字符串类型（学号可能被读取为数字）
                converted_scores = {}
                for key, value in scores.items():
                    converted_scores[str(key)] = value
                return converted_scores
        except json.JSONDecodeError:
            print("成绩数据文件格式错误，将使用空数据")
            return {}
        except Exception as e:
            print(f"读取成绩数据文件时发生错误: {e}")
            return {}

    def save_scores(self, scores):
        """
        保存成绩信息
        输入: 成绩字典
        处理: 将成绩数据写入JSON文件
        """
        try:
            with open(self.score_file, 'w', encoding='utf-8') as f:
                json.dump(scores, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存成绩数据失败: {e}")
            return False

    def export_report_txt(self, statistics_manager, filename):
        """
        导出统计报告为TXT格式
        输入: 统计管理器对象, 文件名
        处理: 生成格式化的文本报告
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                # 写入报告头部
                f.write("=" * 70 + "\n")
                f.write("        学生成绩管理与学习分析系统 - 统计报告\n")
                f.write(f"        生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("=" * 70 + "\n\n")

                # 学生排名
                f.write("一、学生成绩排名（按平均分）\n")
                f.write("-" * 70 + "\n")
                rankings = statistics_manager.get_student_rankings()
                if rankings:
                    f.write(f"{'排名':<4}{'学号':<12}{'姓名':<8}{'班级':<12}{'总分':<8}{'平均分':<8}\n")
                    for i, s in enumerate(rankings, 1):
                        f.write(
                            f"{i:<4}{s['id']:<12}{s['name']:<8}{s['class']:<12}{s['total']:<8.1f}{s['average']:<8.2f}\n")
                else:
                    f.write("暂无成绩数据\n")
                f.write("\n")

                # 课程统计
                f.write("二、各课程统计信息\n")
                f.write("-" * 70 + "\n")
                course_stats = statistics_manager.get_course_stats()
                for course, stats in course_stats.items():
                    if stats['max'] is None:
                        f.write(f"\n【{course}】暂无成绩数据\n")
                    else:
                        f.write(f"\n【{course}】\n")
                        f.write(f"  参考人数: {stats['student_count']}\n")
                        f.write(f"  最高分: {stats['max']:.1f}\n")
                        f.write(f"  最低分: {stats['min']:.1f}\n")
                        f.write(f"  平均分: {stats['average']:.2f}\n")
                        f.write(f"  及格率: {stats['pass_rate']:.1f}%\n")
                        f.write(f"  优秀率: {stats['excellent_rate']:.1f}%\n")
                f.write("\n")

                # 分数段分布
                f.write("三、各课程分数段分布\n")
                f.write("-" * 70 + "\n")
                distributions = statistics_manager.get_score_distribution()
                for course, dist in distributions.items():
                    has_data = any(v > 0 for v in dist.values())
                    if has_data:
                        f.write(f"\n【{course}】\n")
                        total = sum(dist.values())
                        for level, count in dist.items():
                            percentage = count / total * 100 if total > 0 else 0
                            f.write(f"  {level}: {count}人 ({percentage:.1f}%)\n")
                    else:
                        f.write(f"\n【{course}】暂无成绩数据\n")
                f.write("\n")

                # 班级统计
                f.write("四、按班级成绩统计\n")
                f.write("-" * 70 + "\n")
                class_stats = statistics_manager.get_class_stats()
                for class_name, courses in class_stats.items():
                    f.write(f"\n【{class_name}】\n")
                    f.write(f"{'课程':<12}{'参考人数':<8}{'平均分':<10}{'及格率':<10}{'优秀率':<10}\n")
                    f.write("-" * 50 + "\n")
                    for course, stats in courses.items():
                        if stats:
                            f.write(
                                f"{course:<12}{stats['count']:<8}{stats['avg']:<10.2f}{stats['pass_rate']:<10.1f}%{stats['excellent_rate']:<10.1f}%\n")
                        else:
                            f.write(f"{course:<12}{0:<8}{'无数据':<10}{'无数据':<10}{'无数据':<10}\n")

            return True
        except Exception as e:
            print(f"导出TXT报告失败: {e}")
            return False

    def export_report_csv(self, statistics_manager, filename):
        """
        导出统计报告为CSV格式
        输入: 统计管理器对象, 文件名
        处理: 生成CSV格式报告
        """
        try:
            with open(filename, 'w', encoding='utf-8-sig') as f:
                # 学生排名
                f.write("学生成绩排名\n")
                f.write("排名,学号,姓名,班级,总分,平均分\n")
                rankings = statistics_manager.get_student_rankings()
                for i, s in enumerate(rankings, 1):
                    f.write(f"{i},{s['id']},{s['name']},{s['class']},{s['total']:.1f},{s['average']:.2f}\n")
                f.write("\n")

                # 课程统计
                f.write("课程统计\n")
                f.write("课程,参考人数,最高分,最低分,平均分,及格率(%),优秀率(%)\n")
                course_stats = statistics_manager.get_course_stats()
                for course, stats in course_stats.items():
                    if stats['max'] is None:
                        f.write(f"{course},0,无数据,无数据,无数据,无数据,无数据\n")
                    else:
                        f.write(
                            f"{course},{stats['student_count']},{stats['max']:.1f},{stats['min']:.1f},{stats['average']:.2f},{stats['pass_rate']:.1f},{stats['excellent_rate']:.1f}\n")

            return True
        except Exception as e:
            print(f"导出CSV报告失败: {e}")
            return False