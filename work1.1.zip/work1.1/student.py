"""
学生信息管理模块
"""


class StudentManager:
    """学生信息管理类"""

    def __init__(self):
        """初始化学生管理器"""
        # 学生信息使用字典存储，key为学号，value为学生信息字典
        # 数据结构: {学号: {'id':学号, 'name':姓名, 'class':班级, 'gender':性别}}
        self.students = {}

    def add_student(self, stu_id, name, class_name, gender):
        """
        添加学生信息
        输入: 学号, 姓名, 班级, 性别
        处理: 检查学号是否已存在，若不存在则添加
        输出: 布尔值表示是否成功
        """
        if stu_id in self.students:
            return False

        self.students[stu_id] = {
            'id': stu_id,
            'name': name,
            'class': class_name,
            'gender': gender
        }
        return True

    def delete_student(self, stu_id):
        """
        删除学生信息
        输入: 学号
        处理: 查找并删除该学生
        输出: 布尔值表示是否成功
        """
        if stu_id not in self.students:
            return False

        del self.students[stu_id]
        return True

    def modify_student(self, stu_id, name=None, class_name=None, gender=None):
        """
        修改学生信息
        输入: 学号，以及需要修改的字段
        处理: 查找学生并更新非空字段
        输出: 布尔值表示是否成功
        """
        if stu_id not in self.students:
            return False

        if name is not None:
            self.students[stu_id]['name'] = name
        if class_name is not None:
            self.students[stu_id]['class'] = class_name
        if gender is not None:
            self.students[stu_id]['gender'] = gender

        return True

    def find_student(self, stu_id):
        """
        查询学生信息
        输入: 学号
        处理: 查找学生
        输出: 学生信息字典或None
        """
        return self.students.get(stu_id)

    def get_all_students(self):
        """
        获取全部学生信息
        处理: 返回所有学生列表
        输出: 学生信息字典列表
        """
        return list(self.students.values())

    def get_students_by_class(self, class_name):
        """
        按班级获取学生列表
        输入: 班级名称
        处理: 筛选该班级的所有学生
        输出: 学生信息字典列表
        """
        result = []
        for student in self.students.values():
            if student['class'] == class_name:
                result.append(student)
        return result

    def get_all_classes(self):
        """
        获取所有班级列表
        处理: 收集所有不重复的班级名称
        输出: 班级名称列表
        """
        classes = set()
        for student in self.students.values():
            classes.add(student['class'])
        return list(classes)

    def get_student_count(self):
        """获取学生总数"""
        return len(self.students)