"""
学生成绩管理与学习分析系统 - 主程序入口
"""

from student import StudentManager
from score import ScoreManager
from statistics import StatisticsManager
from file_manager import FileManager
from utils import Utils


class MainSystem:
    """系统主类"""

    def __init__(self):
        """初始化系统"""
        self.student_manager = StudentManager()
        self.score_manager = ScoreManager()
        self.statistics_manager = None  # 稍后注入学生和成绩数据
        self.file_manager = FileManager()
        self.running = True

    def load_data(self):
        """加载数据"""
        # 加载学生信息
        students = self.file_manager.load_students()
        if students:
            self.student_manager.students = students
            print(f"成功加载 {len(students)} 条学生信息")
        else:
            print("未找到学生数据文件，将创建新数据")

        # 加载成绩信息
        scores = self.file_manager.load_scores()
        if scores:
            self.score_manager.scores = scores
            print(f"成功加载 {len(scores)} 条成绩记录")
        else:
            print("未找到成绩数据文件，将创建新数据")

        # 初始化统计管理器
        self.statistics_manager = StatisticsManager(
            self.student_manager,
            self.score_manager
        )

    def save_data(self):
        """保存数据"""
        self.file_manager.save_students(self.student_manager.students)
        self.file_manager.save_scores(self.score_manager.scores)
        print("数据已保存")

    def display_main_menu(self):
        """显示主菜单"""
        print("\n" + "=" * 50)
        print("      学生成绩管理与学习分析系统")
        print("=" * 50)
        print("  1. 学生信息管理")
        print("  2. 成绩管理")
        print("  3. 成绩统计分析")
        print("  4. 导出统计报告")
        print("  0. 退出系统")
        print("=" * 50)

    def run_student_management(self):
        """运行学生信息管理子菜单"""
        while True:
            print("\n--- 学生信息管理 ---")
            print("1. 添加学生")
            print("2. 删除学生")
            print("3. 修改学生信息")
            print("4. 查询学生")
            print("5. 显示全部学生")
            print("0. 返回主菜单")

            choice = input("请选择操作: ").strip()

            if choice == "1":
                self._add_student()
            elif choice == "2":
                self._delete_student()
            elif choice == "3":
                self._modify_student()
            elif choice == "4":
                self._query_student()
            elif choice == "5":
                self._display_all_students()
            elif choice == "0":
                break
            else:
                print("输入错误，请重新选择")

    def _add_student(self):
        """添加学生"""
        print("\n--- 添加学生 ---")
        while True:
            stu_id = input("请输入学号: ").strip()
            if not stu_id:
                print("学号不能为空")
                continue
            if self.student_manager.find_student(stu_id):
                print("该学号已存在")
                continue
            break

        name = Utils.get_nonempty_input("请输入姓名: ")
        class_name = Utils.get_nonempty_input("请输入班级: ")
        gender = Utils.get_gender_input("请输入性别(男/女): ")

        if self.student_manager.add_student(stu_id, name, class_name, gender):
            print(f"学生 {name} 添加成功")
        else:
            print("添加失败")

    def _delete_student(self):
        """删除学生"""
        print("\n--- 删除学生 ---")
        stu_id = input("请输入要删除的学号: ").strip()

        # 确认删除
        student = self.student_manager.find_student(stu_id)
        if not student:
            print("该学号不存在")
            return

        print(f"找到学生: {student['name']}，{student['class']}，{student['gender']}")
        confirm = input("确认删除？(y/n): ").strip().lower()

        if confirm == 'y':
            if self.student_manager.delete_student(stu_id):
                # 同时删除该学生的成绩
                self.score_manager.delete_student_scores(stu_id)
                print("删除成功")
            else:
                print("删除失败")
        else:
            print("已取消")

    def _modify_student(self):
        """修改学生信息"""
        print("\n--- 修改学生信息 ---")
        stu_id = input("请输入要修改的学号: ").strip()

        student = self.student_manager.find_student(stu_id)
        if not student:
            print("该学号不存在")
            return

        print(f"当前信息: 姓名={student['name']}, 班级={student['class']}, 性别={student['gender']}")

        name = input(f"请输入新姓名(原:{student['name']}, 直接回车保持不变): ").strip()
        class_name = input(f"请输入新班级(原:{student['class']}, 直接回车保持不变): ").strip()
        gender = input(f"请输入新性别(原:{student['gender']}, 直接回车保持不变): ").strip()

        # 验证性别
        if gender and gender not in ['男', '女']:
            print("性别格式错误，修改失败")
            return

        if self.student_manager.modify_student(stu_id, name or None, class_name or None, gender or None):
            print("修改成功")
        else:
            print("修改失败")

    def _query_student(self):
        """查询学生"""
        print("\n--- 查询学生 ---")
        stu_id = input("请输入学号: ").strip()

        student = self.student_manager.find_student(stu_id)
        if student:
            print("\n查询结果:")
            print(f"  学号: {student['id']}")
            print(f"  姓名: {student['name']}")
            print(f"  班级: {student['class']}")
            print(f"  性别: {student['gender']}")
        else:
            print("未找到该学生")

    def _display_all_students(self):
        """显示全部学生"""
        print("\n--- 全部学生列表 ---")
        students = self.student_manager.get_all_students()
        if not students:
            print("暂无学生数据")
            return

        print("\n学号\t\t姓名\t班级\t性别")
        print("-" * 50)
        for stu in students:
            print(f"{stu['id']}\t{stu['name']}\t{stu['class']}\t{stu['gender']}")

    def run_score_management(self):
        """运行成绩管理子菜单"""
        while True:
            print("\n--- 成绩管理 ---")
            print("1. 录入成绩")
            print("2. 修改成绩")
            print("3. 查询学生全部成绩")
            print("4. 查询某课程全部学生成绩")
            print("5. 查询班级成绩")
            print("0. 返回主菜单")

            choice = input("请选择操作: ").strip()

            if choice == "1":
                self._input_scores()
            elif choice == "2":
                self._modify_score()
            elif choice == "3":
                self._query_student_scores()
            elif choice == "4":
                self._query_course_scores()
            elif choice == "5":
                self._query_class_scores()
            elif choice == "0":
                break
            else:
                print("输入错误，请重新选择")

    def _input_scores(self):
        """录入成绩"""
        print("\n--- 录入成绩 ---")
        stu_id = input("请输入学号: ").strip()

        if not self.student_manager.find_student(stu_id):
            print("该学号不存在，请先添加学生")
            return

        courses = Utils.COURSES
        print(f"可选择的课程: {', '.join(courses)}")

        for course in courses:
            current_score = self.score_manager.get_score(stu_id, course)
            if current_score is not None:
                print(f"{course} 已有成绩: {current_score}，如需修改请使用修改功能")
                continue

            while True:
                score_input = input(f"请输入{course}成绩(0-100，直接回车跳过): ").strip()
                if not score_input:
                    break
                try:
                    score = float(score_input)
                    if Utils.validate_score(score):
                        self.score_manager.set_score(stu_id, course, score)
                        print(f"{course}成绩已录入: {score}")
                        break
                    else:
                        print("成绩必须在0-100之间")
                except ValueError:
                    print("请输入有效的数字")

        print("成绩录入完成")

    def _modify_score(self):
        """修改成绩"""
        print("\n--- 修改成绩 ---")
        stu_id = input("请输入学号: ").strip()

        if not self.student_manager.find_student(stu_id):
            print("该学号不存在")
            return

        print(f"可修改的课程: {', '.join(Utils.COURSES)}")
        course = input("请输入课程名: ").strip()

        if course not in Utils.COURSES:
            print("课程名无效")
            return

        current = self.score_manager.get_score(stu_id, course)
        if current is None:
            print(f"该学生暂无{course}成绩，请使用录入功能")
            return

        print(f"当前{course}成绩: {current}")

        while True:
            try:
                new_score = float(input("请输入新成绩(0-100): ").strip())
                if Utils.validate_score(new_score):
                    self.score_manager.set_score(stu_id, course, new_score)
                    print("修改成功")
                    break
                else:
                    print("成绩必须在0-100之间")
            except ValueError:
                print("请输入有效的数字")

    def _query_student_scores(self):
        """查询学生全部成绩"""
        print("\n--- 查询学生成绩 ---")
        stu_id = input("请输入学号: ").strip()

        student = self.student_manager.find_student(stu_id)
        if not student:
            print("该学号不存在")
            return

        scores = self.score_manager.get_student_scores(stu_id)
        print(f"\n学生: {student['name']} ({stu_id})")
        print(f"班级: {student['class']}")
        print("-" * 30)

        if not scores:
            print("暂无成绩记录")
            return

        total = 0
        count = 0
        for course in Utils.COURSES:
            score = scores.get(course)
            if score is not None:
                print(f"  {course}: {score}")
                total += score
                count += 1
            else:
                print(f"  {course}: 未录入")

        if count > 0:
            avg = total / count
            print(f"\n总分: {total:.1f}, 平均分: {avg:.2f}")

    def _query_course_scores(self):
        """查询某课程全部学生成绩"""
        print("\n--- 查询课程成绩 ---")
        print(f"可选课程: {', '.join(Utils.COURSES)}")
        course = input("请输入课程名: ").strip()

        if course not in Utils.COURSES:
            print("课程名无效")
            return

        all_scores = self.score_manager.get_course_all_scores(course)
        if not all_scores:
            print(f"暂无{course}成绩记录")
            return

        print(f"\n{course}成绩列表:")
        print("学号\t\t姓名\t\t班级\t\t成绩")
        print("-" * 60)

        for stu_id, score in all_scores.items():
            student = self.student_manager.find_student(stu_id)
            if student:
                print(f"{stu_id}\t{student['name']}\t{student['class']}\t{score}")

    def _query_class_scores(self):
        """查询班级成绩"""
        print("\n--- 查询班级成绩 ---")
        class_name = input("请输入班级名称: ").strip()

        # 获取该班级所有学生
        class_students = self.student_manager.get_students_by_class(class_name)
        if not class_students:
            print(f"未找到班级: {class_name}")
            return

        print(f"\n班级: {class_name}")
        print(f"学生人数: {len(class_students)}")
        print("-" * 40)

        # 统计各科平均分
        course_stats = {}
        for course in Utils.COURSES:
            course_stats[course] = {'total': 0, 'count': 0}

        for student in class_students:
            stu_id = student['id']
            scores = self.score_manager.get_student_scores(stu_id)
            for course in Utils.COURSES:
                score = scores.get(course)
                if score is not None:
                    course_stats[course]['total'] += score
                    course_stats[course]['count'] += 1

        print("\n各科平均成绩:")
        for course, stats in course_stats.items():
            if stats['count'] > 0:
                avg = stats['total'] / stats['count']
                print(f"  {course}: {avg:.2f} (参考人数: {stats['count']})")
            else:
                print(f"  {course}: 暂无数据")

    def run_statistics(self):
        """运行统计分析"""
        print("\n--- 成绩统计分析 ---")

        # 刷新统计信息
        self.statistics_manager.refresh()

        print("\n1. 学生总分与平均分排名")
        self.statistics_manager.print_student_rankings()

        print("\n2. 各课程统计信息")
        self.statistics_manager.print_course_statistics()

        print("\n3. 分数段统计")
        self.statistics_manager.print_score_distribution()

        print("\n4. 按班级统计")
        self.statistics_manager.print_class_statistics()

        input("\n按回车键继续...")

    def run_export(self):
        """导出统计报告"""
        print("\n--- 导出统计报告 ---")

        self.statistics_manager.refresh()

        print("1. 导出为TXT格式")
        print("2. 导出为CSV格式")
        print("0. 返回")

        choice = input("请选择: ").strip()

        if choice == "1":
            filename = input("请输入文件名(默认:report.txt): ").strip()
            if not filename:
                filename = "report.txt"
            if not filename.endswith('.txt'):
                filename += '.txt'
            result = self.file_manager.export_report_txt(
                self.statistics_manager, filename
            )
        elif choice == "2":
            filename = input("请输入文件名(默认:report.csv): ").strip()
            if not filename:
                filename = "report.csv"
            if not filename.endswith('.csv'):
                filename += '.csv'
            result = self.file_manager.export_report_csv(
                self.statistics_manager, filename
            )
        else:
            return

        if result:
            print(f"报告已导出到: {filename}")
        else:
            print("导出失败")

    def run(self):
        """运行主程序"""
        print("\n" + "=" * 50)
        print("      学生成绩管理与学习分析系统")
        print("=" * 50)

        self.load_data()

        while self.running:
            self.display_main_menu()
            choice = input("请选择操作(0-4): ").strip()

            if choice == "1":
                self.run_student_management()
            elif choice == "2":
                self.run_score_management()
            elif choice == "3":
                self.run_statistics()
            elif choice == "4":
                self.run_export()
            elif choice == "0":
                print("\n正在保存数据...")
                self.save_data()
                print("感谢使用，再见！")
                self.running = False
                break
            else:
                print("输入错误，请重新选择")


def main():
    """程序入口"""
    try:
        system = MainSystem()
        system.run()
    except KeyboardInterrupt:
        print("\n\n程序被中断，正在保存数据...")
        # 这里无法直接访问system，但KeyboardInterrupt通常不需要复杂处理
        print("再见！")
    except Exception as e:
        print(f"程序发生未预期错误: {e}")
        input("按回车键退出...")


if __name__ == "__main__":
    main()
